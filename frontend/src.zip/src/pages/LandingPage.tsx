import { BentoGridSection } from "../components/Home Modules/BentoGridSection";
import DiscoverSection from "../components/Home Modules/DiscoverSection";
import FeaturesSection from "../components/Home Modules/FeaturesSection";
import FeatureSection from "../components/Home Modules/FeaturesSection";
import Footer from "../components/Home Modules/Footer";
import Hero from "../components/Home Modules/Hero";

function LandingPage() {
  return (
    <>
      <div className="">
        <BentoGridSection />
        <FeaturesSection />
        <Footer />
      </div>
    </>
  );
}

export default LandingPage;
