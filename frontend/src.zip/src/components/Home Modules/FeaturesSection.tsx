export default function FeaturesSection() {
  return (
    <div className="min-h-screen text-white">
      {/* Hero Section - Set-up Autopay */}
      <section className="flex items-center justify-between px-8 py-20 lg:px-20">
        <div className="flex-1">
          <h1 className="text-5xl lg:text-6xl font-bold mb-4">
            Set-up
            <br />
            Autopay
          </h1>
          <p className="text-gray-400 text-lg">Your recurring payments are now our burden.</p>
        </div>
        <div className="flex-1 flex justify-center">
          <div className="relative">
            {/* 3D Calendar */}
            <div className="w-48 h-56 bg-gradient-to-br from-amber-200 to-amber-300 rounded-lg transform rotate-12 shadow-2xl">
              {/* Calendar binding */}
              <div className="absolute -top-4 left-8 right-8 h-8 bg-amber-800 rounded-t-lg"></div>
              <div className="absolute -top-2 left-12 w-4 h-6 bg-gray-800 rounded-sm"></div>
              <div className="absolute -top-2 right-12 w-4 h-6 bg-gray-800 rounded-sm"></div>

              {/* Calendar grid */}
              <div className="p-6 pt-8">
                <div className="grid grid-cols-7 gap-1 mb-2">
                  {Array.from({ length: 21 }, (_, i) => (
                    <div key={i} className="w-4 h-4 bg-amber-100 rounded-sm opacity-60"></div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 14 }, (_, i) => (
                    <div key={i} className="w-4 h-4 bg-amber-100 rounded-sm opacity-60"></div>
                  ))}
                </div>
              </div>

              {/* Green checkmark */}
              <div className="absolute bottom-4 right-4 w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Second Section - No limits */}
      <section className="flex items-center justify-between px-8 py-20 lg:px-20">
        <div className="flex-1 flex justify-center">
          {/* Speedometer */}
          <div className="relative w-64 h-64">
            <div className="w-full h-full border-4 border-gray-700 rounded-full bg-gray-900 shadow-2xl">
              {/* Speedometer marks */}
              <div className="absolute inset-4 border border-gray-600 rounded-full">
                <div className="absolute inset-2 border border-gray-500 rounded-full">
                  {/* Speed marks */}
                  {Array.from({ length: 12 }, (_, i) => (
                    <div
                      key={i}
                      className="absolute w-0.5 h-4 bg-gray-400"
                      style={{
                        top: "10px",
                        left: "50%",
                        transformOrigin: "50% 110px",
                        transform: `translateX(-50%) rotate(${i * 30}deg)`,
                      }}
                    />
                  ))}

                  {/* Red needle */}
                  <div className="absolute top-1/2 left-1/2 w-1 h-20 bg-red-500 rounded-full shadow-lg transform -translate-x-1/2 -translate-y-full origin-bottom rotate-45">
                    <div className="absolute -bottom-2 left-1/2 w-4 h-4 bg-red-500 rounded-full transform -translate-x-1/2"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex-1">
          <h2 className="text-5xl lg:text-6xl font-bold mb-4">
            No limits on
            <br />
            Bank UPI
            <br />
            payments
          </h2>
          <p className="text-gray-400 text-lg">When it comes to money, we set no boundaries!</p>
        </div>
      </section>

      {/* Third Section - Your number is your UPI ID */}
      <section className="flex items-center justify-between px-8 py-20 lg:px-20">
        <div className="flex-1">
          <h2 className="text-5xl lg:text-6xl font-bold mb-4">
            Your number
            <br />
            is your UPI ID
          </h2>
          <p className="text-gray-400 text-lg">Payments are just a dial away</p>
        </div>
        <div className="flex-1 flex justify-center">
          {/* Chat Interface */}
          <div className="relative">
            {/* Chat bubble 1 */}
            <div className="bg-gray-700 text-white px-4 py-2 rounded-2xl rounded-bl-sm mb-4 max-w-xs">
              Yo, where should I send the money?
            </div>

            {/* Chat bubble 2 */}
            <div className="bg-green-600 text-white px-4 py-2 rounded-2xl rounded-br-sm ml-8 mb-2 max-w-xs">Hi</div>

            {/* Chat bubble 3 */}
            <div className="bg-green-600 text-white px-4 py-3 rounded-2xl rounded-br-sm ml-8 max-w-xs flex items-center gap-2">
              You can send it on this number!
              <span className="text-lg">😊</span>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Section - Private by default */}
      <section className="text-center px-8 py-20 lg:px-20">
        {/* Blue padlock */}
        <div className="flex justify-center mb-8">
          <div className="w-24 h-32 relative">
            {/* Lock body */}
            <div className="absolute bottom-0 w-full h-20 bg-blue-500 rounded-lg shadow-2xl">
              {/* Keyhole */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-3 h-3 bg-blue-900 rounded-full"></div>
                <div className="w-1 h-4 bg-blue-900 mx-auto"></div>
              </div>
            </div>
            {/* Lock shackle */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-12 h-16 border-4 border-blue-500 rounded-t-full"></div>
          </div>
        </div>

        <h2 className="text-4xl lg:text-5xl font-bold mb-4">
          Private by default.
          <br />
          Secure by nature.
        </h2>
        <p className="text-gray-400 text-lg max-w-md mx-auto">
          All payments are end-to-end encrypted. An extremely secure gateway for everything private.
        </p>
      </section>
    </div>
  )
}
