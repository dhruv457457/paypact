import React from "react";
import {
  FaBolt,
  FaShieldAlt,
  FaWallet,
  FaUsers,
  FaMoneyBillWave,
  FaBriefcase,
} from "react-icons/fa";

function Hero() {
  return (
    <section
      className="relative min-h-[90vh] flex flex-col items-center justify-center overflow-hidden"
      style={{
        backgroundColor: "var(--colors-secondary)",
        color: "var(--colors-base-100)",
        fontFamily: "var(--font-family-sans)",
      }}
    >
      {/* Background Shapes - Positioned like reference */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Left side shapes */}
        <div
          className="absolute w-20 h-80 rounded-[2rem] opacity-15 transform rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            left: "8%",
            top: "15%",
          }}
        ></div>
        <div
          className="absolute w-16 h-64 rounded-[2rem] opacity-12 transform rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            left: "15%",
            top: "45%",
          }}
        ></div>
        <div
          className="absolute w-12 h-48 rounded-[1.5rem] opacity-10 transform rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            left: "22%",
            top: "25%",
          }}
        ></div>

        {/* Right side shapes */}
        <div
          className="absolute w-24 h-96 rounded-[2rem] opacity-15 transform -rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            right: "8%",
            top: "10%",
          }}
        ></div>
        <div
          className="absolute w-18 h-72 rounded-[2rem] opacity-12 transform -rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            right: "16%",
            top: "40%",
          }}
        ></div>
        <div
          className="absolute w-14 h-56 rounded-[1.5rem] opacity-10 transform -rotate-12"
          style={{
            backgroundColor: "var(--colors-base-300)",
            right: "24%",
            top: "20%",
          }}
        ></div>

        {/* Additional background elements for depth */}
        <div
          className="absolute w-10 h-32 rounded-[1rem] opacity-8 transform rotate-20"
          style={{
            backgroundColor: "var(--colors-base-300)",
            left: "5%",
            bottom: "20%",
          }}
        ></div>
        <div
          className="absolute w-12 h-40 rounded-[1rem] opacity-8 transform -rotate-20"
          style={{
            backgroundColor: "var(--colors-base-300)",
            right: "5%",
            bottom: "25%",
          }}
        ></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl">
        <h1 className="text-6xl md:text-7xl font-bold mb-8 leading-tight">
          Secure, user-friendly payments
          <br />
          <span>for everyone</span>
        </h1>

        <div className="flex justify-center items-center gap-6 flex-wrap mb-12">
          <button
            className="px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
            style={{
              backgroundColor: "var(--colors-primary)",
              color: "var(--colors-secondary)",
            }}
          >
            Get Started for Free
          </button>
          <button
            className="underline underline-offset-4 transition-all duration-300 hover:opacity-80 text-lg"
            style={{ color: "var(--colors-primary)" }}
          >
            Learn more →
          </button>
        </div>

        {/* Feature Pills */}
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <FeaturePill icon={<FaBolt />} text="Fast & Simple Payments" />
          <FeaturePill icon={<FaShieldAlt />} text="High Security" />
          <FeaturePill icon={<FaWallet />} text="Multiple Payment Options" />
          <FeaturePill icon={<FaUsers />} text="User Reputation" />
          <FeaturePill icon={<FaMoneyBillWave />} text="Low Fees" />
          <FeaturePill icon={<FaBriefcase />} text="Business Tools" />
        </div>
      </div>
    </section>
  );
}

function FeaturePill({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div
      className="flex items-center gap-3 border rounded-full px-5 py-3 text-sm shadow-sm transition-all duration-300 hover:scale-105 backdrop-blur-sm"
      style={{
        backgroundColor: "rgba(0, 0, 0, 0.6)",
        borderColor: "var(--colors-base-300)",
        color: "var(--colors-base-100)",
      }}
    >
      <span style={{ color: "var(--colors-primary)" }}>{icon}</span>
      <span>{text}</span>
    </div>
  );
}

export default Hero;