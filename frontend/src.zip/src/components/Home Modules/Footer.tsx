import React from "react";
import { FaFacebook, FaInstagram, FaTelegram, FaYoutube } from "react-icons/fa";

function Footer() {
  return (
    <footer
      className="relative py-16 px-6"
      style={{
     
        color: "var(--colors-base-100)",
        fontFamily: "var(--font-family-sans)",
      }}
    >
      {/* CTA Button */}
      <div className="max-w-7xl mx-auto mb-16">
        <button
          className="w-full py-6 rounded-3xl text-2xl md:text-3xl font-bold transition-all duration-300 hover:scale-[1.02] shadow-2xl"
          style={{
            background: `linear-gradient(135deg, var(--colors-primary) 0%, var(--colors-primary_high) 100%)`,
            color: "var(--colors-secondary)",
          }}
        >
          Start using PayPact today
        </button>
      </div>

      <div className="max-w-7xl mx-auto">
        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="text-2xl font-bold">PayPact</div>
              <div
                className="w-8 h-8 rounded transform rotate-12 flex items-center justify-center"
                style={{ backgroundColor: "var(--colors-primary)" }}
              >
                <span style={{ color: "var(--colors-secondary)" }}> P </span>
              </div>
            </div>
          </div>

          {/* Your Trusted Payment Partner */}
          <div>
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Your Trusted Payment Partner
            </h3>
            <p
              className="text-sm leading-relaxed mb-4"
              style={{ color: "var(--colors-base-300)" }}
            >
              PayPact is a secure, user-friendly payment platform that makes sending, receiving, and managing money simple.
            </p>
          </div>

          {/* Why Choose PayPact? */}
          <div>
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Why Choose PayPact?
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "var(--colors-base-300)" }}
            >
              We focus on speed, transparency, and trust, so both individuals and businesses can make transactions confidently.
            </p>
          </div>

          {/* Get Started in Minutes */}
          <div>
            <h3
              className="text-xl font-bold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Get Started in Minutes
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "var(--colors-base-300)" }}
            >
              With no setup fees and low transaction charges, PayPact is suitable for startups, freelancers, and personal use.
            </p>
          </div>
        </div>

        {/* Bottom Section */}
        <div
          className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8 pt-8 border-t"
          style={{ borderColor: "var(--colors-base-300)" }}
        >
          {/* Social Media */}
          <div>
            <h4
              className="text-lg font-semibold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Follow us on
              <br />
              social media
            </h4>
            <div className="flex gap-3">
              <SocialButton icon={<FaFacebook />} />
              <SocialButton icon={<FaInstagram />} />
              <SocialButton icon={<FaTelegram />} />
              <SocialButton icon={<FaYoutube />} />
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h4
              className="text-lg font-semibold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Product
            </h4>
            <div className="space-y-3">
              <FooterLink text="Personal" />
              <FooterLink text="Business" />
              <FooterLink text="Pricing" />
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4
              className="text-lg font-semibold mb-4"
              style={{ color: "var(--colors-base-100)" }}
            >
              Company
            </h4>
            <div className="space-y-3">
              <FooterLink text="About Us" />
              <FooterLink text="Careers" />
              <FooterLink text="Contact" />
            </div>
          </div>

          {/* App Download */}
          <div>
            <div className="flex items-start gap-4">
              <div
                className="w-16 h-16 rounded-lg flex items-center justify-center border-2"
                style={{ borderColor: "var(--colors-base-300)" }}
              >
                <div className="w-12 h-12 bg-white rounded grid grid-cols-6 gap-px p-1">
                  {Array.from({ length: 36 }).map((_, i) => (
                    <div
                      key={i}
                      className=" rounded-sm"
                      style={{
                        backgroundColor:
                          Math.random() > 0.5 ? "black" : "transparent",
                      }}
                    />
                  ))}
                </div>
              </div>
              <div>
                <h4
                  className="text-lg font-semibold mb-2"
                  style={{ color: "var(--colors-base-100)" }}
                >
                  Your financial future
                  <br />
                  in your hands
                </h4>
                <button
                  className="text-sm underline underline-offset-2 transition-all duration-300 hover:opacity-80"
                  style={{ color: "var(--colors-primary)" }}
                >
                  Download the app →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialButton({ icon }: { icon: React.ReactNode }) {
  return (
    <button
      className="w-10 h-10 rounded-full border transition-all duration-300 hover:scale-110 flex items-center justify-center"
      style={{
        borderColor: "var(--colors-base-300)",
        color: "var(--colors-base-100)",
      }}
    >
      {icon}
    </button>
  );
}

function FooterLink({ text }: { text: string }) {
  return (
    <button
      className="text-sm transition-all duration-300 hover:opacity-80 block text-left"
      style={{ color: "var(--colors-base-300)" }}
    >
      {text}
    </button>
  );
}

export default Footer;